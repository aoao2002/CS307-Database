//实现对应的业务逻辑
//我们所有的api在这里实现就好
//利用Dao对象来和数据库交互
//增删改查后将本应该输出到cmd的输出打包（Arraylist等）, 直接返回
//这些返回值会在controler中传入到前端显示

//添加注解@Transactional进行事务的处理
package com.example.proj2.service;

import java.util.ArrayList;
import java.util.List;
import com.example.proj2.bean.Staff;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface StaffService {

    /**
     * 保存用户对象
     * @param staff
     */
    void save(Staff staff);

    List<Staff> getUserList();


    //public List<Staff> queryByName();

    ArrayList<String> findNumberGroupByType();



}

