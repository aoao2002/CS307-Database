package com.example.proj2.service;

import com.example.proj2.bean.Contract;
import com.example.proj2.dao.ContractDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContractServiceMpl implements ContractService{
    @Autowired
    private ContractDao contractDao;

    public Contract findByNum(String num)
    {
        return contractDao.findByNum(num);
    }

    public int countContract(){
        return contractDao.findAll().size();
    }
}