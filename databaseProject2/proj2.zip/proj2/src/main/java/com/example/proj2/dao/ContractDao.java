package com.example.proj2.dao;

import com.example.proj2.bean.Contract;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface ContractDao extends CommonDao<Contract>{
    Contract findByNum(String num);
    List<Contract> findAll();
    @Transactional
    @Modifying
    @Query(value = "truncate table contract RESTART IDENTITY CASCADE;",nativeQuery = true)
    void truncateTable();
}
