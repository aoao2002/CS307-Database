//package com.example.proj2.redis;
//
//import com.example.proj2.bean.Inventory;
//import com.example.proj2.service.InventoryService;
//import com.fasterxml.jackson.annotation.JsonAutoDetect;
//import com.fasterxml.jackson.annotation.PropertyAccessor;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.springframework.context.annotation.Bean;
//import org.springframework.data.redis.connection.RedisConnectionFactory;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
//import org.springframework.data.redis.serializer.StringRedisSerializer;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//import javax.annotation.Resource;
//import java.util.List;
//
////在运行程序后，自动将查询到的剩余库存线性加入Redis中
//@Component
//public class SecKill {
//    @Resource
//    private InventoryService inventoryService;
//    @Resource
//    private RedisTemplate<Object, Object> redis;
//
//    @Scheduled(cron = "0/5 * * * * ?")
//    public void startSeckill() {
//        List<Inventory> inventories = inventoryService.findAll();
//        for (Inventory inventory : inventories) {
//                redis.delete("seckill:count:" + inventory.getId());
//            //这个表每一行都是容量为1的商品
//            for (int i = 0; i < inventory.getQuantity(); i++) {
//                redis.opsForList().rightPush("seckill:count:" + inventory.getId(), inventory.getId());
//            }
//        }
//    }
//
//
//
//}
//
//
