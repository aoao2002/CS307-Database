package com.example.proj2.service;
import com.example.proj2.dao.StaffDao;
import com.example.proj2.bean.Staff;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class StaffServiceMpl implements StaffService {
    @Autowired
    private StaffDao staffDao;


    public void save(Staff staff)
    {

        staffDao.save(staff);
    }

    @Override
    public List<Staff> getUserList() {
        return staffDao.findAll();
    }

    public ArrayList<String> findNumberGroupByType(){
        ArrayList<String> output = staffDao.findNumberGroupByType();
        return output;
    }


}
