package com.example.proj2.service;


import com.example.proj2.bean.*;

import java.util.HashSet;

public class ModelInfo {
    public HashSet<Model> models;
    private long quantity;

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }
    public long getQuantity() {
        return quantity;
    }
}
