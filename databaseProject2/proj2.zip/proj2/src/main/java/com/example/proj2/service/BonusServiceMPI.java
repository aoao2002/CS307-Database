package com.example.proj2.service;
import com.example.proj2.bean.*;
import com.example.proj2.dao.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.crypto.Data;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


@Service
public class BonusServiceMPI implements BonusService {
    @Autowired
    private SupplyCenterDao supplyCenterDao;
    @Autowired
    private InventoryDao inventoryDao;
    @Autowired
    private StaffDao staffDao;
    @Autowired
    private ProductDao productDao;
    @Autowired
    private StokeInfoDao stokeInfoDao;
    @Autowired
    private ModelDao modelDao;
    @Autowired
    private ContractDao contractDao;
    @Autowired
    private ClientEnterpriseDao clientEnterpriseDao;
    @Autowired
    private ContractOrderDao contractOrderDao;

    public List<ContractOrder> UpdateOrderState(){
        Date date = new Date(System.currentTimeMillis());
        List<ContractOrder> UpDateContractOrders = new ArrayList<>();
        List<ContractOrder> contractOrders = contractOrderDao.findAll();
        for(ContractOrder contractOrder : contractOrders){
            if(contractOrder.getLodgementDate().compareTo(date) > 0 && contractOrder.getState().equals("Finished")){
                contractOrder.setState("Not Finished");
                contractOrderDao.save(contractOrder);
                UpDateContractOrders.add(contractOrder);
            }else if (contractOrder.getLodgementDate().compareTo(date) <= 0 && contractOrder.getState().equals("Not Finished")){
                contractOrder.setState("Finished");
                contractOrderDao.save(contractOrder);
                UpDateContractOrders.add(contractOrder);
            }
        }
        System.out.println(UpDateContractOrders.size());
        return UpDateContractOrders;
    }
}
