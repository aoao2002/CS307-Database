package com.example.proj2.controller;

import com.example.proj2.bean.Inventory;
import com.example.proj2.service.APIService;
import com.example.proj2.service.APIServiceMPI;
import com.example.proj2.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
public class InventoryController {
    @Autowired
    private InventoryService inventoryService;
    @Autowired
    private APIService apiService;


    @RequestMapping("/getAvgStockByCenter")
    public String getAllStaffCount(Model model){
        List<String> output = inventoryService.countAvgInventory();
        int size = output.size();
        String[] index;
        ArrayList<InventoryInfo> inventoryInfos=new ArrayList<>();
        for (int i = 0; i < size; i++) {
            index=output.get(i).split(",");
            inventoryInfos.add(new InventoryInfo(index[0],index[1]));
        }
        model.addAttribute("inventoryInfos",inventoryInfos);
        return "getAvgStockByCenter";
    }

    @RequestMapping("/prepareSecKill")
    @ResponseBody
    public String prepareSecKill(Model model){
        inventoryService.addSecKill();
        return "okk";
    }

    @RequestMapping("/showResult")
    @ResponseBody
    public String showResult(Model model){
        return inventoryService.getSecKillLeft(1)+"";
    }

    @RequestMapping("/secKill")
    @ResponseBody
    //@Cacheable(value = "categoryList")
    public String secKill(){
        //Inventory inventory = inventoryService.findById(1);
        return inventoryService.secKill(1)+"";
        //long inventoryId = redisTemplate.opsForList().leftPop("seckill:count:1");
    }

    @RequestMapping("/getProductByNumber")
    public String getProductByNumber(Model model,String productNumber) {
        model.addAttribute("modelInfos",apiService.getProductByNumber(productNumber));
        //System.out.println(apiService.getProductByNumber(productNumber).size());
        return "getProductByNumber";
    }


}

