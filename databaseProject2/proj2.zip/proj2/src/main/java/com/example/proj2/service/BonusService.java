package com.example.proj2.service;
import com.example.proj2.bean.ContractOrder;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
public interface BonusService {
    List<ContractOrder> UpdateOrderState();
}
