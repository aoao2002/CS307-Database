package com.example.proj2.service;

import com.example.proj2.bean.Inventory;
import com.example.proj2.dao.InventoryDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventoryServiceMpl implements InventoryService {
    @Autowired
    InventoryDao inventoryDao;
    @Autowired
    private RedisTemplate redisTemplate;

    public List<String> countAvgInventory(){
        return inventoryDao.findAvgGroupByCenter();
    }

    public List<Inventory> findAll(){
        return inventoryDao.findAll();
    }

    public void addSecKill(){
        int value = 5000;
        Inventory inventory = inventoryDao.findById(1);
        inventory.setQuantity(value);
        inventoryDao.save(inventory);

        redisTemplate.delete("seckill:count:" + inventory.getId());
        //这个表每一行都是容量为1的商品
        for (int i = 0; i < value; i++) {
            redisTemplate.opsForList().rightPush("secKill:count:" + inventory.getId(), inventory.getId());
        }

    }

    public Inventory findById(long id){
        return inventoryDao.findById(id);
    }


    public long secKill(long id){
        long output=redisTemplate.opsForList().size("secKill:count:"+id);
        Integer inventoryId=(Integer) redisTemplate.opsForList().leftPop("secKill:count:"+id);
//        if(inventoryId==null) {
//            System.out.println("sold out: "+output);
//        }else {
//            System.out.println("you get it: "+output);
//        }
        if(inventoryId==null) {
            System.out.println("sold out: ");
        }else {
            System.out.println("you get it: ");
        }
//        Inventory inventory=inventoryDao.findById(id);
//        if(output<=inventory.getQuantity()) {
//            inventory.setQuantity(output);
//            inventoryDao.save(inventory);
//        }
        return output;
    }

    @Override
    public long getSecKillLeft(long id) {
        Inventory inventory = inventoryDao.findById(id);
        inventory.setQuantity(redisTemplate.opsForList().size("secKill:count:"+id));
        inventoryDao.save(inventory);
        return inventory.getQuantity();
    }
}
