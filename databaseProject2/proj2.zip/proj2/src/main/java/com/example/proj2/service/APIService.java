package com.example.proj2.service;

import org.jboss.jandex.ModuleInfo;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
public interface APIService {
    //提供api
    void stockIn();
    void placeOrder();
    long getNeverSoldProductCount();
    ModelInfo getFavoriteProductModel();
    List<ModelMoreInfo> getProductByNumber(String productNumber);
}
