package com.example.proj2.service;

import com.example.proj2.bean.*;
import com.example.proj2.dao.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class IDSUServiceMPI implements IDSUService {
    @Autowired
    private SupplyCenterDao supplyCenterDao;
    @Autowired
    private InventoryDao inventoryDao;
    @Autowired
    private StaffDao staffDao;
    @Autowired
    private ProductDao productDao;
    @Autowired
    private StokeInfoDao stokeInfoDao;
    @Autowired
    private ModelDao modelDao;
    @Autowired
    private ContractDao contractDao;
    @Autowired
    private ClientEnterpriseDao clientEnterpriseDao;
    @Autowired
    private ContractOrderDao contractOrderDao;

    public boolean InsertStaffInfo(String ageS,String gender,String phoneS,String staff_name,String numberS,
                                String type,String supply_center){

        long phone;
        long number;
        SupplyCenter supplyCenter=supplyCenterDao.findByName(supply_center);
        if (supplyCenter==null){
            System.out.println("No such supply center");
            return false;
        }
        if (!gender.equals("Male")&&!gender.equals("Female")){
            System.out.println("Gender is invalid!");
            return false;
        }
        if (phoneS.length()!=11||!(phoneS.matches("^[0-9]{11}$"))){
            System.out.println("The phone number is invalid!");
            return false;
        }
        if (!(numberS.matches("[0-9]*"))){
            System.out.println("The staff number is invalid!");
            return false;
        }
        if (!type.equals("Director")&&!type.equals("Salesman")
                &&!type.equals("Contracts Manager")&&!type.equals("Supply Staff")){
            System.out.println("The staff type is invalid!");
            return  false;
        }


        phone=Long.parseLong(phoneS);
        number=Long.parseLong(numberS);
        Staff staff=new Staff();
        if(!"".equals(ageS)){
            int age=Integer.parseInt(ageS);
            staff.setAge(age);
        }

        staff.setMobile_number(phone);
        staff.setName(staff_name);
        staff.setSupplyCenter(supplyCenter);
        staff.setNumber(number);
        staff.setGender(gender);
        staff.setType(type);
        staffDao.save(staff);
        return true;
    }


    public boolean DeleteStaffInfo(String ageS,String gender,String phoneS,String staff_name,String numberS,
                                   String type,String supply_center){
        //staffDao.cancelForeignKeyConstraint();
        List<Staff> staffAll=staffDao.findAll();
        ArrayList<Staff> staffs = new ArrayList<>();
        for (Staff staff:staffAll) {
            if("".equals(ageS)||(staff.getAge()+"").equals(ageS)){
                if ("".equals(gender)||staff.getGender().equals(gender)){
                    if ("".equals(phoneS)||(staff.getMobile_number()+"").equals(phoneS)){
                        if ("".equals(staff_name)||staff.getName().equals(staff_name)){
                            if ("".equals(numberS)||(staff.getNumber()+"").equals(numberS)){
                                if ("".equals(type)||staff.getType().equals(type)){
                                    if ("".equals(supply_center)||staff.getSupplyCenter().getName().equals(supply_center)){
                                        //staffs.add(staff);
                                        staffDao.delete(staff);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        //staffDao.deleteAll(staffs);
        return true;
    }

    public boolean UpdateStaffInfo(String ageS,String gender,String phoneS,String staff_name,String numberS,
                            String type,String supply_center){
        //int age=Integer.parseInt(ageS);
        long phone;
        long number;
        SupplyCenter supplyCenter=supplyCenterDao.findByName(supply_center);
        if (supplyCenter==null){
            System.out.println("No such supply center");
            return false;
        }
        if (!gender.equals("Male")&&!gender.equals("Female")){
            System.out.println("Gender is invalid!");
            return false;
        }
        if (phoneS.length()!=11||!(phoneS.matches("^[0-9]{11}$"))){
            System.out.println("The phone number is invalid!");
            return false;
        }
        if (!(numberS.matches("[0-9]*"))){
            System.out.println("The staff number is invalid!");
            return false;
        }
        if (!type.equals("Director")&&!type.equals("Salesman")
                &&!type.equals("Contracts Manager")&&!type.equals("Supply Staff")){
            System.out.println("The staff type is invalid!");
            return  false;
        }
        phone=Long.parseLong(phoneS);
        number=Long.parseLong(numberS);
        Staff staff=staffDao.findByNumber(number);
        if (staff==null){
            System.out.println("No such staff");
            return false;
        }
        if(!"".equals(ageS)){
            int age=Integer.parseInt(ageS);
            staff.setAge(age);
        }

        staff.setMobile_number(phone);
        staff.setName(staff_name);
        staff.setSupplyCenter(supplyCenter);
        staff.setGender(gender);
        staff.setType(type);
        staffDao.save(staff);
        return true;
    }
    public ArrayList<Staff> SelectStaffInfo(String ageS,String gender,String phoneS,String staff_name,String numberS,
                                            String type,String supply_center){

        ArrayList<Staff> staffs=new ArrayList<>();
        List<Staff> staffAll=staffDao.findAll();
        for (Staff staff:staffAll) {
            if("".equals(ageS)||(staff.getAge()+"").equals(ageS)){
                if ("".equals(gender)||staff.getGender().equals(gender)){
                    if ("".equals(phoneS)||(staff.getMobile_number()+"").equals(phoneS)){
                        if ("".equals(staff_name)||staff.getName().equals(staff_name)){
                            if ("".equals(numberS)||(staff.getNumber()+"").equals(numberS)){
                                if ("".equals(type)||staff.getType().equals(type)){
                                    if ("".equals(supply_center)||staff.getSupplyCenter().getName().equals(supply_center)){
                                        staffs.add(staff);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return staffs;
    }

//    public ArrayList<Staff> SelectOrderInfo(String ageS,String gender,String phoneS,String staff_name,String numberS,
//                                            String type,String supply_center){
//        ArrayList<Staff> staffs=new ArrayList<>();
//        List<Staff> staffAll=staffDao.findAll();
//        for (Staff staff:staffAll) {
//            if("".equals(ageS)||(staff.getAge()+"").equals(ageS)){
//                if ("".equals(gender)||staff.getGender().equals(gender)){
//                    if ("".equals(phoneS)||(staff.getMobile_number()+"").equals(phoneS)){
//                        if ("".equals(staff_name)||staff.getName().equals(staff_name)){
//                            if ("".equals(numberS)||(staff.getNumber()+"").equals(numberS)){
//                                if ("".equals(type)||staff.getType().equals(type)){
//                                    if ("".equals(supply_center)||staff.getSupplyCenter().getName().equals(supply_center)){
//                                        staffs.add(staff);
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//        }
//        return staffs;
//    }
}
