package com.example.proj2.bean;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.springframework.context.annotation.Primary;

import javax.persistence.*;

@Entity
@Table(name = "SupplyCenter")
public class SupplyCenter extends BaseBean{
    @Column(unique = true)
    private String name;
    @ManyToOne
    @NotFound(action= NotFoundAction.IGNORE)
    @JoinColumn(name="DirectorId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Staff director;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Staff getDirector() {
        return director;
    }

    public void setDirector(Staff director) {
        this.director = director;
    }
}
