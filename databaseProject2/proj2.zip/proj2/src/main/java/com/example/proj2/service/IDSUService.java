package com.example.proj2.service;

import com.example.proj2.bean.Staff;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;

@Transactional
public interface IDSUService {
    boolean InsertStaffInfo(String ageS,String gender,String phoneS,String staff_name,String numberS,
                         String type,String supply_center);
    boolean DeleteStaffInfo(String ageS,String gender,String phoneS,String staff_name,String numberS,
                            String type,String supply_center);
    boolean UpdateStaffInfo(String ageS,String gender,String phoneS,String staff_name,String numberS,
                            String type,String supply_center);
    ArrayList<Staff> SelectStaffInfo(String ageS,String gender,String phoneS,String staff_name,String numberS,
                                     String type,String supply_center);
//    ArrayList<Staff> SelectOrderInfo(String log,String est,String quantityS,String state,String contractS,
//                                            String salesman,String supply_center);
}
