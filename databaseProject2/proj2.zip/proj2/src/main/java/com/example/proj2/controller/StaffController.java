//controller可以相应网页对应的操作、
//应该在这里调用service的方法
package com.example.proj2.controller;

import com.example.proj2.bean.Staff;
import com.example.proj2.service.IDSUService;
import com.example.proj2.service.IDSUServiceMPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.example.proj2.service.StaffService;
import org.springframework.ui.Model;

import java.util.ArrayList;
import java.util.List;

@Controller
public class StaffController {
    //使用改对象操作
    //添加该注释就不同new了
    @Autowired
    private StaffService staffService;
    @Autowired
    private IDSUService idsuService;

    //该注释响应对应的网页
    @RequestMapping("/staff")
    @ResponseBody// 返回值直接被解析成字符串，而不会对应到相应的html
    public String hello() {
        return "Hello staff !!!";
    }

    @RequestMapping("/test1")
    @ResponseBody
    public String test1() {
        return "0";
    }
    @RequestMapping("/index")
    public String index(Model model) {
        //model-->这个对象，是用于存储数据，将数据带回页面
        //往前台传数据，可以传对象，可以传List，通过el表达式 ${}可以获取到
        //即前端利用th接受数据
        //model.addAttribute("name", "myc");
        //model.addAttribute("age", 19);
        //model.addAttribute("info", "CS307,yyds");
        //返回的页面文件
        return "index";
    }

    @RequestMapping("/getAllStaffCount")
    public String getAllStaffCount(Model model){
        ArrayList<String> output = staffService.findNumberGroupByType();

        int size = output.size();
        String[] index=new String[2];
        for (int i = 0; i < size; i++) {
            index=output.get(i).split(",");
            if(index[0].equals("Supply Staff")) index[0]="SupplyStaff";
            if(index[0].equals("Contracts Manager")) index[0]="ContractsManager";
            model.addAttribute(index[0],index[1]);
        }
        return "staffNumGroupByType";
    }

    @RequestMapping("/insertStaff")
    @ResponseBody
    public String insertStaff(Model model,
                              String staffName,
                              String staffNumber,
                              String staffPhone,
                              String gender,
                              String age,
                              String type,
                              String supplyCenter
                              ){
        if (idsuService.InsertStaffInfo(age,gender,staffPhone,staffName,staffNumber,
                type,supplyCenter)){
            return "insertStaff has been done";
        }
        return "false for wrong input";

    }

    @RequestMapping("/deleteStaff")
    @ResponseBody
    public String deleteStaff(Model model,
                              String staffName,
                              String staffNumber,
                              String staffPhone,
                              String gender,
                              String age,
                              String type,
                              String supplyCenter
    ){
        idsuService.DeleteStaffInfo(age,gender,staffPhone,staffName,staffNumber,
                type,supplyCenter);
        return "deleteStaff has been done";


    }

    @RequestMapping("/updateStaff")
    @ResponseBody
    public String updateStaff(Model model,
                              String staffName,
                              String staffNumber,
                              String staffPhone,
                              String gender,
                              String age,
                              String type,
                              String supplyCenter
    ){
        if(idsuService.UpdateStaffInfo(age,gender,staffPhone,staffName,staffNumber,
                type,supplyCenter)) {
            return "updateStaff has been done";
        }
        return "false for wrong input";
    }

    @RequestMapping("/queryStaff")
    public String queryStaff(Model model,
                              String staffName,
                              String staffNumber,
                              String staffPhone,
                              String gender,
                              String age,
                              String type,
                              String supplyCenter
    ){
        model.addAttribute("staffs",
                idsuService.SelectStaffInfo
                        (age,gender,staffPhone,staffName,staffNumber,type,supplyCenter));

        return "selectStaff";
    }


}
