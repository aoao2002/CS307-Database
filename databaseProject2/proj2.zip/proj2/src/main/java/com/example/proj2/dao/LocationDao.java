package com.example.proj2.dao;
import com.example.proj2.bean.Location;
import com.zaxxer.hikari.HikariConfig;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface LocationDao extends CommonDao<Location>{
    Location findByCityAndCountry(String city,String country);
    @Transactional
    @Modifying
    @Query(value = "truncate table location RESTART IDENTITY CASCADE;",nativeQuery = true)
    void truncateTable();
}
