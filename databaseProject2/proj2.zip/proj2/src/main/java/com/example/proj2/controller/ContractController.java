//controller可以相应网页对应的操作、
//应该在这里调用service的方法
package com.example.proj2.controller;

import com.example.proj2.bean.Contract;
import com.example.proj2.bean.ContractOrder;
import com.example.proj2.service.*;
import com.example.proj2.service.ContractService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
public class ContractController {
    @Autowired
    private  ContractService contractService;
    @Autowired
    private  ContractOrderService contractOrderService;
    @Autowired APIService apiService;
    @Autowired
    private BonusService bonusService;

    @RequestMapping("/getContractInfo")
    public String getContractInfo(Model model,String num) {
        Contract contract = contractService.findByNum(num);

        List<ContractOrder> orders = contractOrderService.findOrderByNum(num);
        model.addAttribute("contracts",contract);
        model.addAttribute("orders",orders);

        return "getContractInfo";
    }

    @RequestMapping("/updateOrder")
    @ResponseBody
    public String updateOrder(Model model) {
        contractOrderService.updateOrder();
            return "updateOrder success";
    }

    @RequestMapping("/deleteOrder")
    @ResponseBody
    public String deleteOrder(Model model) {
        contractOrderService.deleteOrder();
        return "deleteOrder success";
    }

    @RequestMapping("/getNeverSoldProductCount")
    @ResponseBody
    public String getNeverSoldProductCount(Model model) {
       return  apiService.getNeverSoldProductCount()+"";
    }


    @RequestMapping("/getContractCount")
    public String getContractCount(Model model) {
        model.addAttribute("number", contractService.countContract());
        return "getContractCount";
    }

    @RequestMapping("/getOrderCount")
    public String getOrderCount(Model model) {
        model.addAttribute("number",contractOrderService.countOrder());
        return "getContractCount";
    }

    @RequestMapping("/getFavoriteProductModel")
    public String getFavoriteProductModel(Model model){
        String[] index=contractOrderService.getFavoriteProductModel().get(0).split(",");

        model.addAttribute("maxModel",index[0]);
        model.addAttribute("quantity",index[1]);

        return "getFavoriteProductModel";
    }

    @RequestMapping("/UpdateOrderState")
    public String UpdateOrderState(Model model){
        model.addAttribute("UpdatedOrderState",bonusService.UpdateOrderState());
        return "UpdatedOrderState";
    }
}
