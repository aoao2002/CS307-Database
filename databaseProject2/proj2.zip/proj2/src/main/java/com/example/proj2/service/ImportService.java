package com.example.proj2.service;

import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface ImportService {
    //提供api
    //清空所有表
    void deleteAllTable();
    //导入四个csv
    void importStaff();
    void importCenter();
    void importModel();
    void importEnterPrise();
}
