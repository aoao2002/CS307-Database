package com.example.proj2.dao;

import com.example.proj2.bean.Inventory;
import com.example.proj2.bean.StokeInfo;
import com.example.proj2.bean.SupplyCenter;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.proj2.bean.Staff;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface StokeInfoDao extends CommonDao<SupplyCenter>{

    StokeInfo save(StokeInfo stokeInfo);
    //List<StokeInfo> findByInventory(Inventory inventory);
    @Transactional
    @Modifying
    @Query(value = "truncate table stoke_info RESTART IDENTITY CASCADE;",nativeQuery = true)
    void truncateTable();
}
