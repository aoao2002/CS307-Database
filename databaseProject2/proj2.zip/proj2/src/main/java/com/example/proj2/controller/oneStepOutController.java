package com.example.proj2.controller;

import com.example.proj2.bean.Contract;
import com.example.proj2.bean.ContractOrder;
import com.example.proj2.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class oneStepOutController {
    @Autowired
    private ContractService contractService;
    @Autowired
    private ContractOrderService contractOrderService;
    @Autowired
    private StaffService staffService;
    @Autowired
    private InventoryService inventoryService;
    @Autowired
    private APIService apiService;


    @RequestMapping("/One-step export")
    public String getContractInfo(Model model) {
        //Q6
        ArrayList<String> output = staffService.findNumberGroupByType();
        int size = output.size();
        String[] index=null;
        for (int i = 0; i < size; i++) {
            index=output.get(i).split(",");
            if(index[0].equals("Supply Staff")) index[0]="SupplyStaff";
            if(index[0].equals("Contracts Manager")) index[0]="ContractsManager";
            model.addAttribute(index[0],index[1]);
        }
        //Q7
        model.addAttribute("numberOfContracts",contractService.countContract());
        //Q8
        model.addAttribute("numberOfOrders",contractOrderService.countOrder());
        //9
        model.addAttribute("numberOfUnsoldOrders",apiService.getNeverSoldProductCount());
        //Q10
        List<String> favModel=contractOrderService.getFavoriteProductModel();
        if(favModel.size()==0){
            model.addAttribute("maxModel","no model was sold");
            model.addAttribute("quantity","0");
        }else {
            index=contractOrderService.getFavoriteProductModel().get(0).split(",");
            model.addAttribute("maxModel",index[0]);
            model.addAttribute("quantity",index[1]);
        }


        //Q11
        List<String> countAvgInventoryOutput = inventoryService.countAvgInventory();
        size = countAvgInventoryOutput.size();
        ArrayList<InventoryInfo> inventoryInfos=new ArrayList<>();
        for (int i = 0; i < size; i++) {
            index=countAvgInventoryOutput   .get(i).split(",");
            inventoryInfos.add(new InventoryInfo(index[0],index[1]));
        }
        model.addAttribute("inventoryInfos",inventoryInfos);
        //Q12
        model.addAttribute("modelInfos",
                apiService.getProductByNumber("A50L172"));
        //Q13
        Contract contract = contractService.findByNum("CSE0000106");
        List<ContractOrder> orders = contractOrderService.findOrderByNum("CSE0000106");
        model.addAttribute("contracts1",contract);
        model.addAttribute("orders1",orders);

        contract = contractService.findByNum("CSE0000209");
        orders = contractOrderService.findOrderByNum("CSE0000209");
        model.addAttribute("contracts2",contract);
        model.addAttribute("orders2",orders);

        contract = contractService.findByNum("CSE0000306");
        orders = contractOrderService.findOrderByNum("CSE0000306");
        model.addAttribute("contracts3",contract);
        model.addAttribute("orders3",orders);

        return "oneStepOutput";
    }
}
