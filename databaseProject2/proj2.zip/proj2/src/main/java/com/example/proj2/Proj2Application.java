
package com.example.proj2;
import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.HikariPoolMXBean;
import com.zaxxer.hikari.pool.HikariPool;
import org.hibernate.engine.jdbc.connections.internal.DatasourceConnectionProviderImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.DirectFieldAccessor;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.batch.BatchDataSource;
import org.springframework.boot.jdbc.metadata.HikariDataSourcePoolMetadata;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.Resource;
import javax.management.JMX;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.sql.DataSource;
import java.lang.management.ManagementFactory;
import java.sql.Connection;
import java.sql.SQLException;

@SpringBootApplication
@RestController
@EnableScheduling
@EnableCaching
public class Proj2Application implements CommandLineRunner{

	@Resource
	private HikariDataSource dataSource;

	//private static HikariPoolMXBean poolProxy;

	private static final Logger logger = LoggerFactory.getLogger(Proj2Application.class);

	@Override
	public void run(String... args) throws Exception {
		try(Connection conn = dataSource.getConnection()) {
			System.out.println(conn);
		}
	}

	//启动位置
	public static void main(String[] args) throws SQLException, MalformedObjectNameException, InterruptedException{
		SpringApplication.run(DatasourceConfigApplication.class, args);
		//hikaridatasource.setRegisterMbeans(true);

		//MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
		//ObjectName poolName =
		//		new ObjectName("com.zaxxer.hikari:type=Pool (MdmApiHikariPool)");
		//poolProxy = JMX.newMXBeanProxy(mBeanServer, poolName, HikariPoolMXBean.class);

	}

	@Scheduled(fixedRate = 1000)
	public void HikariMonitor() {
		HikariPool hikariPool = (HikariPool)
				new DirectFieldAccessor(dataSource).getPropertyValue("pool");

//			logger.info("HikariPoolState = "
//					+ "Active=[" + String.valueOf(hikariPool.getActiveConnections() + "] "
//					+ "Idle=[" + String.valueOf(hikariPool.getIdleConnections() + "] "
//					+ "Wait=["+hikariPool.getThreadsAwaitingConnection()+"] "
//					+ "Total=["+hikariPool.getTotalConnections()+"]")));

	}

}
