package com.example.proj2.bean;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.springframework.context.annotation.Primary;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Contract")
public class Contract extends BaseBean{
    @Column(unique = true)
    private String num;

    @Temporal(TemporalType.DATE)
    @Column(name = "Date", nullable = true, length = 12)
    private Date date;

    @ManyToOne
    @NotFound(action= NotFoundAction.IGNORE)
    @JoinColumn(name="ClientEnterpriseId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private ClientEnterprise clientEnterprise;

    public Staff getContractsManager() {
        return ContractsManager;
    }

    public void setContractsManager(Staff contractsManager) {
        ContractsManager = contractsManager;
    }

    @ManyToOne
    @JoinColumn(name="ContractsManagerId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    @NotFound(action= NotFoundAction.IGNORE)
    private Staff ContractsManager;

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public ClientEnterprise getClientEnterprise() {
        return clientEnterprise;
    }

    public void setClientEnterprise(ClientEnterprise clientEnterprise) {
        this.clientEnterprise = clientEnterprise;
    }
}
