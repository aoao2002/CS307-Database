package com.example.proj2.service;

import com.example.proj2.bean.*;
import com.example.proj2.dao.*;
import org.jboss.jandex.ModuleInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.crypto.Data;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

@Service
public class APIServiceMPI implements APIService {
    @Autowired
    private SupplyCenterDao supplyCenterDao;
    @Autowired
    private InventoryDao inventoryDao;
    @Autowired
    private StaffDao staffDao;
    @Autowired
    private ProductDao productDao;
    @Autowired
    private StokeInfoDao stokeInfoDao;
    @Autowired
    private ModelDao modelDao;
    @Autowired
    private ContractDao contractDao;
    @Autowired
    private ClientEnterpriseDao clientEnterpriseDao;
    @Autowired
    private ContractOrderDao contractOrderDao;


    SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

    public void stockIn(){

        ArrayList<String[]> stokes =
                ContractOrderServiceMpl.readCsv("in_stoke_test.csv");
//        ArrayList<String[]> stokes =
//                ContractOrderServiceMpl.readCsv("task1_in_stoke_test_data_publish.csv");
        //System.out.println("start to stock in");
        for(String[] stoke : stokes){
            Staff staff;
            SupplyCenter supplyCenter;
            Model model;
            boolean CenterHasBlank = false;
            StokeInfo stokeInfo = new StokeInfo();
            if (stoke[1].charAt(0) == '"'){
                CenterHasBlank = true;
                stoke[1] += stoke[2];
                stoke[1] = stoke[1].substring(1, stoke[1].length()-1);
                staff = staffDao.findByNumber(Long.parseLong(stoke[4]));
                supplyCenter = supplyCenterDao.findByName(stoke[1]);
                model = modelDao.findByModelName(stoke[3]);
                stokeInfo.setPurchase_price(Long.parseLong(stoke[6]));
                stoke[5]=stoke[5].replace("/","-");
                try {
                    stokeInfo.setDate(sdf.parse(stoke[5]));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                stokeInfo.setQuantity(Long.parseLong(stoke[7]));
            }else {
                staff = staffDao.findByNumber(Long.parseLong(stoke[3]));
                supplyCenter = supplyCenterDao.findByName(stoke[1]);
                model=modelDao.findByModelName(stoke[2]);
                stokeInfo.setPurchase_price(Long.parseLong(stoke[5]));
                stoke[4]=stoke[4].replace("/","-");
                try {
                    stokeInfo.setDate(sdf.parse(stoke[4]));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                stokeInfo.setQuantity(Long.parseLong(stoke[6]));
            }
            if (staff == null || supplyCenter == null){
               // System.out.println("The staff or supply center not found");
            }else if (!staff.getType().equals("Supply Staff")){
                //System.out.println("The staff is not a supply staff");
            }else if (staff.getSupplyCenter() != supplyCenter){
                //System.out.println("The staff doesn't match the supply center");
            }else if(model == null){
                //System.out.println("The product is not found");
            }else {
                Inventory inventory = new Inventory();
                Inventory inventoryUsed=inventoryDao.findByModelAndSupplyCenter(model,supplyCenter);
                inventory.setModel(model);
                inventory.setSupplyCenter(supplyCenter);
                if (CenterHasBlank){
                    inventory.setQuantity(Long.parseLong(stoke[7]));
                }else {
                    inventory.setQuantity(Long.parseLong(stoke[6]));
                }
                if (inventoryUsed==null){
                    //inventoryList.add(inventory);
                    inventory=inventoryDao.save(inventory);
                }else {
                    if (CenterHasBlank){
                        inventoryUsed.setQuantity(inventoryUsed.getQuantity()+Long.parseLong(stoke[7]));
                    }else {
                        inventoryUsed.setQuantity(inventoryUsed.getQuantity()+Long.parseLong(stoke[6]));
                    }
                    inventory=inventoryDao.save(inventoryUsed);

                }
                stokeInfo.setSupplyStaff(staff);
                stokeInfo.setInventory(inventory);
                stokeInfoDao.save(stokeInfo);
            }
        }
    }

    public void placeOrder(){
        ArrayList<String[]> orders =
                ContractOrderServiceMpl.readTsv("task2_test_data_final_public.tsv");
//        ArrayList<String[]> orders =
//                ContractOrderServiceMpl.readCsv("task2_test_data_publish.csv");
        System.out.println("start to place order");
        for(String[] orderInfo : orders){
            Staff staff=staffDao.findByNumber(Long.parseLong(orderInfo[8]));
            Model model=modelDao.findByModelName(orderInfo[2]);
            ClientEnterprise clientEnterprise=clientEnterpriseDao.findByName(orderInfo[1]);
            Inventory inventory=inventoryDao.findByModelAndSupplyCenter(model,clientEnterprise.getSupplyCenter());
            if (!staff.getType().equals("Salesman")){
                //System.out.println("The staff is not a salesman");
            }else if (inventory==null||inventory.getQuantity()<Long.parseLong(orderInfo[3])){
                /////还能找不到库存？
                //System.out.println("The inventory is not enough");
            }else {
                Contract contract= contractDao.findByNum(orderInfo[0]);
                inventory.setQuantity(inventory.getQuantity()-Long.parseLong(orderInfo[3]));
                inventoryDao.save(inventory);
                if (contract==null){
                    contract=new Contract();
                    Staff manager=staffDao.findByNumber(Long.parseLong(orderInfo[4]));
                    contract.setClientEnterprise(clientEnterprise);
                    contract.setContractsManager(manager);
                    contract.setNum(orderInfo[0]);
                    orderInfo[5]=orderInfo[5].replace("/","-");
                    try {
                        contract.setDate(sdf.parse(orderInfo[5]));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    contractDao.save(contract);
                }
                ContractOrder contractOrder=new ContractOrder();
                contractOrder.setContract(contract);
                contractOrder.setModel(model);
                contractOrder.setQuantity(Long.parseLong(orderInfo[3]));
                contractOrder.setSalesman(staff);
                orderInfo[6]=orderInfo[6].replace("/","-");
                try {
                    contractOrder.setEstimatedDeliveryDate(sdf.parse(orderInfo[6]));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                orderInfo[7]=orderInfo[7].replace("/","-");
                try {
                    contractOrder.setLodgementDate(sdf.parse(orderInfo[7]));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                contractOrder.setState(orderInfo[9]);
                contractOrderDao.save(contractOrder);
            }
        }
    }

    //api9
    public long getNeverSoldProductCount(){
        HashSet<Model> Models=new HashSet<>();
        for (Inventory inventory:inventoryDao.findAll()){
            if (inventory.getQuantity()!=0){
                Models.add(inventory.getModel());
            }
        }
        for (ContractOrder contractOrder:contractOrderDao.findAll()){
            Models.remove(contractOrder.getModel());
        }
        return Models.size();
    }

    //api11
    public ModelInfo getFavoriteProductModel(){
        ModelInfo modelInfo=new ModelInfo();
        for (ContractOrder contractOrder:contractOrderDao.findAll()){
            if(modelInfo.models.contains(contractOrder.getModel())&&contractOrder.getQuantity()>0){
                modelInfo.models.clear();
                modelInfo.models.add(contractOrder.getModel());
                modelInfo.setQuantity(modelInfo.getQuantity()+contractOrder.getQuantity());
            }else {
                if (contractOrder.getQuantity()>modelInfo.getQuantity()){
                    modelInfo.models.clear();
                    modelInfo.models.add(contractOrder.getModel());
                    modelInfo.setQuantity(contractOrder.getQuantity());
                }
            }
        }
        return modelInfo;
    }
    //api12
    public List<ModelMoreInfo> getProductByNumber(String product_number){
        List<ModelMoreInfo> modelMoreInfoS=new ArrayList<>();
        Product product=productDao.findByProductCode(product_number);
        //System.out.println(modelDao.findByProductCode(product).size());
        for (Model model:modelDao.findByProductCode(product)){
            for (Inventory inventory:inventoryDao.findByModel(model)){
                ModelMoreInfo modelMoreInfo=new ModelMoreInfo();
                modelMoreInfo.setModel(model);
                modelMoreInfo.setQuantity(inventory.getQuantity());
                modelMoreInfo.setSupplyCenter(inventory.getSupplyCenter());
                modelMoreInfoS.add(modelMoreInfo);
            }
        }
        //System.out.println("infos: "+modelMoreInfoS.size());
        return modelMoreInfoS;
    }
}
