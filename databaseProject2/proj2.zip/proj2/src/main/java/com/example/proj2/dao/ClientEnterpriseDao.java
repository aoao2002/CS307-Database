package com.example.proj2.dao;

import com.example.proj2.bean.ClientEnterprise;
import com.example.proj2.bean.Location;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface ClientEnterpriseDao extends CommonDao<ClientEnterprise>{
    ClientEnterprise findByName(String name);
    @Transactional
    @Modifying
    @Query(value = "truncate table client_enterprise RESTART IDENTITY CASCADE;",nativeQuery = true)
    void truncateTable();
}
