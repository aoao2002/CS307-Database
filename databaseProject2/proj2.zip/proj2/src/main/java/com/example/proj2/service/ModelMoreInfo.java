package com.example.proj2.service;

import com.example.proj2.bean.*;

public class ModelMoreInfo {
    private Model model;
    private long quantity;
    private SupplyCenter supplyCenter;

    public void setModel(Model model) {
        this.model = model;
    }
    public Model getModel() {
        return model;
    }
    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }
    public long getQuantity() {
        return quantity;
    }
    public void setSupplyCenter(SupplyCenter supplyCenter) {
        this.supplyCenter = supplyCenter;
    }
    public SupplyCenter getSupplyCenter() {
        return supplyCenter;
    }
}
