package com.example.proj2.dao;

import com.example.proj2.bean.Model;
import com.example.proj2.bean.Product;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ModelDao extends CommonDao<Model>{
    List<Model> findByProductCode(Product product);
    Model findByModelName(String ModelName);
    @Transactional
    @Modifying
    @Query(value = "truncate table model RESTART IDENTITY CASCADE;",nativeQuery = true)
    void truncateTable();
}
