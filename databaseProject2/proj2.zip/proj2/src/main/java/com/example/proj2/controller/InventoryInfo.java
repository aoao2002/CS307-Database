package com.example.proj2.controller;

class InventoryInfo
{
    public String name;
    public String avg;
    public InventoryInfo(String name,String avg){
        this.name=name;
        this.avg=avg;
    }
}
