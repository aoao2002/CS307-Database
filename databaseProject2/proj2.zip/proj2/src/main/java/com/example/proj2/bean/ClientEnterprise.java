package com.example.proj2.bean;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.springframework.context.annotation.Primary;

import javax.persistence.*;

@Entity
@Table(name = "ClientEnterprise")
public class ClientEnterprise extends BaseBean {
    @Column(unique = true)
    private String name;
    private String industry;
    @ManyToOne
    @NotFound(action= NotFoundAction.IGNORE)
    @JoinColumn(name="SupplyCenterId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private SupplyCenter supplyCenter;
    @ManyToOne
    @NotFound(action=NotFoundAction.IGNORE)
    @JoinColumn(name="LocationId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Location location;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public SupplyCenter getSupplyCenter() {
        return supplyCenter;
    }

    public void setSupplyCenter(SupplyCenter supplyCenter) {
        this.supplyCenter = supplyCenter;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }
}
