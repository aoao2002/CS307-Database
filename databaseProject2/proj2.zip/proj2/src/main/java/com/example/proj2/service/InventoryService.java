package com.example.proj2.service;

import com.example.proj2.bean.Inventory;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Transactional
public interface InventoryService {
    List<String> countAvgInventory();
    List<Inventory> findAll();
    void addSecKill();
    Inventory findById(long id);
    long secKill(long id);
    long getSecKillLeft(long id);
}
