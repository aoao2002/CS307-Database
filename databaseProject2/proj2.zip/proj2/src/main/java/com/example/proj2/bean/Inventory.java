package com.example.proj2.bean;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.springframework.context.annotation.Primary;

import javax.persistence.*;

@Entity
@Table(name = "Inventory")
public class Inventory extends BaseBean{
    @ManyToOne
    @NotFound(action= NotFoundAction.IGNORE)
    @JoinColumn(name="SupplyCenterId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private SupplyCenter supplyCenter;

    @ManyToOne
    @NotFound(action=NotFoundAction.IGNORE)
    @JoinColumn(name="ModelId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Model model;

    private long quantity;

    public SupplyCenter getSupplyCenter() {
        return supplyCenter;
    }

    public void setSupplyCenter(SupplyCenter supplyCenter) {
        this.supplyCenter = supplyCenter;
    }

    public Model getModel() {
        return model;
    }
    public void setModel(Model model) {
        this.model = model;
    }

    public long getQuantity() {
        return quantity;
    }

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }
}
