package com.example.proj2.service;

import com.example.proj2.bean.*;
import com.example.proj2.dao.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;

import javax.persistence.Id;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Properties;

@Service
public class ImportServiceMpl implements ImportService{
    @Autowired
    private SupplyCenterDao supplyCenterDao;
    @Autowired
    private StaffDao staffDao;
    @Autowired
    private ModelDao modelDao;
    @Autowired
    private ProductDao productDao;
    @Autowired
    private LocationDao locationDao;
    @Autowired
    private ClientEnterpriseDao clientEnterpriseDao;
    @Autowired
    private ContractDao contractDao;
    @Autowired
    private ContractOrderDao contractOrderDao;
    @Autowired
    private InventoryDao inventoryDao;

    ArrayList<SupplyCenter> supplyCenters = new ArrayList<>();
    ArrayList<Staff> Staffs = new ArrayList<>();
    ArrayList<Model> Models=new ArrayList<>();
    ArrayList<Location>     Locations=new ArrayList<>();
    ArrayList<ClientEnterprise> clientEnterprises=new ArrayList<>();


    public void deleteAllTable(){
        System.out.println("try to truncate all table");
        supplyCenters = new ArrayList<>();
        Staffs = new ArrayList<>();
        Models=new ArrayList<>();
        Locations=new ArrayList<>();
        clientEnterprises=new ArrayList<>();
        modelDao.truncateTable();
        productDao.truncateTable();
        staffDao.truncateTable();
        clientEnterpriseDao.truncateTable();
        locationDao.truncateTable();
        supplyCenterDao.truncateTable();
        inventoryDao.truncateTable();
        contractOrderDao.truncateTable();
        contractDao.truncateTable();

    }

    public void importCenter(){
        ArrayList<String[]> centers =
                ContractOrderServiceMpl.readCsv("center.csv");
        System.out.println("try to import center");
        for (String[] index : centers) {
            SupplyCenter supplyCenter = new SupplyCenter();
            supplyCenter.setId(Long.parseLong(index[0]));
            if (index[1].charAt(0) == '"') {
                index[1] += index[2];
                index[1] = index[1].substring(1, index[1].length() - 1);
            }
            supplyCenter.setName(index[1]);
            supplyCenters.add(supplyCenter);
        }
        supplyCenters.sort(Comparator.comparing(SupplyCenter::getId));
        supplyCenterDao.saveAll(supplyCenters);
        System.out.println("over");
    }

    public void importStaff(){
        System.out.println("try to import staff.csv");
        ArrayList<String[]> staffs = ContractOrderServiceMpl.readCsv("staff.csv");
        for (String[] index : staffs) {
            Staff staff = new Staff();
            staff.setId(Long.parseLong(index[0]));
            staff.setName(index[1]);
            staff.setAge(Integer.parseInt(index[2]));
            staff.setGender(index[3]);
            staff.setNumber(Long.parseLong(index[4]));
            if (index[5].charAt(0) == '"') {
                String sc = index[5] + index[6];
                sc = sc.substring(1, sc.length() - 1);
                staff.setSupplyCenter(supplyCenterDao.findByName(sc));
                staff.setMobile_number(Long.parseLong(index[7]));
                staff.setType(index[8]);
            } else {
                staff.setSupplyCenter(supplyCenterDao.findByName(index[5]));
                staff.setMobile_number(Long.parseLong(index[6]));
                staff.setType(index[7]);
            }
            Staffs.add(staff);
            staffDao.save(staff);
            if (staff.getType().equals("Director")){
                for (SupplyCenter supplyCenter : supplyCenters) {
                    if (supplyCenter.getName().equals(staff.getSupplyCenter().getName())){
                        supplyCenter.setDirector(staff);
                        supplyCenterDao.save(supplyCenter);
                    }
                }
            }
        }
        System.out.println("over");
    }

    public void importModel(){
        System.out.println("try to import model.csv");
        ArrayList<String[]> models = ContractOrderServiceMpl.readCsv("model.csv");
        for (String[] index : models) {
            if (productDao.findByProductCode(index[1]) != null) {
                continue;
            }
            Product product = new Product();
            product.setProductCode(index[1]);
            product.setName(index[3]);

            productDao.save(product);

        }
        for (String[] index : models) {
            Model model = new Model();
            model.setId(Long.parseLong(index[0]));
            model.setModelName(index[2]);
            model.setUnit_price(Integer.parseInt(index[4]));
            model.setProductCode(productDao.findByProductCode(index[1]));
            Models.add(model);
        }
        modelDao.saveAll(Models);
        System.out.println("over");

    }

    public void importEnterPrise(){
        System.out.println("try to import enterprise.csv");
        ArrayList<String[]> enterprises = ContractOrderServiceMpl.readCsv("enterprise.csv");

        for (String[] index : enterprises) {
            Location location = new Location();
            location.setCountry(index[2]);
            if (index[2].equals("China")){
                location.setCity(index[3]);
            }
            if (locationDao.findByCityAndCountry(location.getCity(), location.getCountry()) != null) {
                continue;
            }
            Locations.add(location);
            locationDao.save(location);
        }

        for (String[] index : enterprises) {
            ClientEnterprise clientEnterprise = new ClientEnterprise();
            clientEnterprise.setId(Long.parseLong(index[0]));
            clientEnterprise.setName(index[1]);
            if (index[4].charAt(0) == '"') {
                index[4] = index[4] + index[5];
                index[4] = index[4].substring(1, index[4].length() - 1);
                clientEnterprise.setIndustry(index[6]);
            }else {
                clientEnterprise.setIndustry(index[5]);
            }
            clientEnterprise.setSupplyCenter
                    (supplyCenterDao.findByName(index[4]));
            if (index[2].equals("China")) {
                clientEnterprise.setLocation(locationDao.findByCityAndCountry(index[3], index[2]));
            }else {
                clientEnterprise.setLocation(locationDao.findByCityAndCountry(null,index[2] ));
            }
            clientEnterprises.add(clientEnterprise);
        }
        clientEnterprises.sort(Comparator.comparing(ClientEnterprise::getId));
        clientEnterpriseDao.saveAll(clientEnterprises);
        System.out.println("over");
    }
}