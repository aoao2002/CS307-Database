package com.example.proj2.dao;

import com.example.proj2.bean.Product;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface ProductDao extends CommonDao<Product>{
    Product findByProductCode(String productCode);
    @Transactional
    @Modifying
    @Query(value = "truncate table product RESTART IDENTITY CASCADE;",nativeQuery = true)
    void truncateTable();
}
