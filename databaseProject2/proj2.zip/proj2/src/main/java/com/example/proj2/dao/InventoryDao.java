package com.example.proj2.dao;

import com.example.proj2.bean.*;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Repository
public interface InventoryDao extends CommonDao<Inventory>{

    List<Inventory> findAll();

    Inventory findByModelAndSupplyCenter(Model model, SupplyCenter supplyCenter);

    List<Inventory>findByModel(Model model);
    @Transactional
    @Modifying
    @Query(value = "truncate table inventory RESTART IDENTITY CASCADE;",nativeQuery = true)
    void truncateTable();

    @Query(nativeQuery = true,value=
            "select sc.name,cast(round(avg(quantity),1) as numeric(20,1))\n" +
            "from inventory\n" +
            "join model m on m.id = inventory.model_id\n" +
            "join supply_center sc on inventory.supply_center_id = sc.id\n" +
            "group by sc.name\n" +
            "order by sc.name\n" +
            ";")
    List<String> findAvgGroupByCenter();

    Inventory findById(long id);

    //    @Transactional
//    @Modifying
//    @Query(value = "update inventory set quantity =:quantity where model_id = :model " +
//            "and supply_center_id =:supplyCenter",nativeQuery = true)
//    void updateQuantity(@Param("quantity")long quantity,
//                        @Param("model")long modelId,@Param("supplyCenter")long supplyCenterId);
}
