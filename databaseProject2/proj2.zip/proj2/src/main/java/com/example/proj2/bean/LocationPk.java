package com.example.proj2.bean;


import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

//对应联合主键的处理
//要求继承Serializable
//必须提供一个public的无参数构造函数。
//必须重写hashCode()和equals()这两个方法，用于判断主键是否相等

//在对应的实体类中，直接使用该类
//如：
//@EmbeddedId
//private StaffPk id


@Embeddable
public class LocationPk implements Serializable {

    private String city;
    private String country;
    private String id;

    //alt insert 自动生成


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LocationPk)) return false;
        LocationPk that = (LocationPk) o;
        return Objects.equals(getCity(), that.getCity()) && getCountry().equals(that.getCountry());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCity(), getCountry());
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public LocationPk(){

    }




}
