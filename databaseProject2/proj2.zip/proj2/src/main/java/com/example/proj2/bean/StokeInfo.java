package com.example.proj2.bean;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.springframework.context.annotation.Primary;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "stokeInfo")
public class StokeInfo extends BaseBean{
    @ManyToOne
    @NotFound(action= NotFoundAction.IGNORE)
    @JoinColumn(name="InventoryId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Inventory inventory;


    @ManyToOne
    @NotFound(action=NotFoundAction.IGNORE)
    @JoinColumn(name="supplyStaffId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Staff supplyStaff;

    @Temporal(TemporalType.DATE)
    @Column(name = "date", nullable = true, length = 12)
    private Date Date;
    private long purchase_price;
    private long quantity;

    public void setDate(Date date) {
        this.Date = date;
    }
    public Date getDate() {
        return Date;
    }
    public void setPurchase_price(long purchase_price) {
        this.purchase_price = purchase_price;
    }
    public long getPurchase_price() {
        return purchase_price;
    }
    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }
    public long getQuantity() {
        return quantity;
    }
    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
    public Inventory getInventory() {
        return inventory;
    }
    public void setSupplyStaff(Staff supplyStaff) {
        this.supplyStaff = supplyStaff;
    }
    public Staff getSupplyStaff() {
        return supplyStaff;
    }
}
