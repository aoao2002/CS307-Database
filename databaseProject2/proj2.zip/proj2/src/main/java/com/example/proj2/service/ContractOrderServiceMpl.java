package com.example.proj2.service;

import com.example.proj2.bean.*;
import com.example.proj2.dao.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.csvreader.CsvReader;

import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@Service
public class ContractOrderServiceMpl implements ContractOrderService{
    @Autowired
    private ContractOrderDao contractOrderDao;

    @Autowired
    private StaffDao staffDao;

    @Autowired
    private InventoryDao inventoryDao;

    @Autowired
    private ContractDao contractDao;
    @Autowired
    private ModelDao modelDao;

    public void deleteOrder(){
        //ArrayList<String[]> unDeletedOrders=readTsv("task34_delete_test_data_publish.tsv");
        ArrayList<String[]> unDeletedOrders=readTsv("delete_final.tsv");
        long testSize=unDeletedOrders.size();
        //按顺序删除order
        String[] index;
        List<ContractOrder> orders=null;

        for (int i = 0; i < testSize; i++) {
            //每一次删除一类order
            index=unDeletedOrders.get(i);
            Staff salesman = staffDao.findByNumber(Long.parseLong(index[1]));
            Contract contract = contractDao.findByNum(index[0]);
            if(contract==null) continue;
            if(salesman==null) continue;
            if(!salesman.getType().equals("Salesman")){
                //System.out.println("the type is not salesman");
                continue;
            }
            orders=contractOrderDao.findByContractAndSalesman(contract.getNum(),salesman.getNumber());
            int seq=Integer.parseInt(index[2]);
            if(seq>orders.size()) continue;
            ContractOrder contractOrder=orders.get(seq-1);
            //更新库存
            Inventory inventory=inventoryDao.findByModelAndSupplyCenter(
                    contractOrder.getModel(),
                    contractOrder.getContract().getClientEnterprise().getSupplyCenter()
            );
            inventory.setQuantity(inventory.getQuantity()+contractOrder.getQuantity());
            inventoryDao.save(inventory);
            contractOrderDao.delete(contractOrder);

        }

    }

    public List<ContractOrder> updateOrder(){

//        List<ContractOrder> orders=contractOrderDao.findAll();
//        for (int i = 0; i < orders.size(); i++) {
//            System.out.println(
//                    orders.get(i).getContract().getNum()+","+
//                    orders.get(i).getContract().getClientEnterprise().getName()+","+
//                    orders.get(i).getModel().getModelName()+","+
//                    orders.get(i).getContract().getContractsManager().getNumber()+","+
//                    orders.get(i).getSalesman().getNumber()+","
//             );
//        }

        SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
        //ArrayList<String[]> newOrders=readTsv("task34_update_test_data_publish.tsv");
        ArrayList<String[]> newOrders=readTsv("update_final_test.tsv");
        long testSize=newOrders.size();
        String[] index;
        ContractOrder lastOrder;

        Inventory inventory=null;
        Contract contract=null;
        Model model=null;
        Staff staff=null;
        for (int i = 0; i < testSize; i++) {
            //每一次循环更新一个order
            index=newOrders.get(i);
            contract=contractDao.findByNum(index[0]);
            model=modelDao.findByModelName(index[1]);
            staff=staffDao.findByNumber(Long.parseLong(index[2]));

            inventory=inventoryDao.findByModelAndSupplyCenter(model,contract.getClientEnterprise().getSupplyCenter());

            if(inventory==null){
                //System.out.println("inventory not find");
                continue;
            }

            if(!staff.getType().equals("Salesman")) {
                //System.out.println("staff is not Salesman");
                continue;
            }

            lastOrder=contractOrderDao.findByContractAndModelAndSalesman(contract,model,staff);

            if(lastOrder==null) {
                //System.out.println("this order is not found");
                continue;
            }

            inventory.setQuantity(inventory.getQuantity() +
                    lastOrder.getQuantity() - Integer.parseInt(index[3]));

            if(inventory.getQuantity()<0) continue;

            inventoryDao.save(inventory);

            try {
                lastOrder.setLodgementDate(ft.parse(index[5]));
                lastOrder.setEstimatedDeliveryDate(ft.parse(index[4]));
            } catch (Exception e) {
                e.printStackTrace();
            }

            lastOrder.setQuantity(Integer.parseInt(index[3]));

            //System.out.println(lastOrder.getQuantity());

            if(lastOrder.getQuantity()<=0){
                contractOrderDao.deleteById(lastOrder.getId());
                //System.out.println("delete this order: "+lastOrder.getContract().getNum()+" "+lastOrder.getId());
            }else {
                contractOrderDao.save(lastOrder);
                //System.out.println("update this order"+lastOrder.getContract().getNum()+" "+lastOrder.getId());
            }

        }
        return null;
    }

    public int countOrder(){
        return contractOrderDao.findAll().size();
    }

    public static ArrayList<String[]> readCsv(String fileName) {
        ArrayList<String[]> output = new ArrayList<>();
        try (Scanner sc = new Scanner(new FileReader(fileName))) {
            boolean firstLine=true;
            int cnt=0;
            while (sc.hasNextLine()) {  //按行读取字符串
                String line = sc.nextLine();
                if(firstLine){
                    firstLine=false;
                    continue;
                }
                output.add(line.split(","));
            }
        }catch (IOException ioe){
            ioe.printStackTrace();
        }
        return output;
    }

    public static ArrayList<String[]> readTsv(String fileName){
        ArrayList<String[]> output = new ArrayList<>();
        try (Scanner sc = new Scanner(new FileReader(fileName))) {
            boolean firstLine=true;
            int cnt=0;
            while (sc.hasNextLine()) {  //按行读取字符串
                String line = sc.nextLine();
                if(firstLine){
                    firstLine=false;
                    continue;
                }
                output.add(line.split("\t"));
            }
        }catch (IOException ioe){
            ioe.printStackTrace();
        }
        return output;
    }

    public List<ContractOrder> findOrderByNum(String num){
        return contractOrderDao.findByContract(contractDao.findByNum(num));
    }

    public List<String> getFavoriteProductModel(){
        return contractOrderDao.getFavoriteProductModel();
    }

}

