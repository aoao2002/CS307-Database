package com.example.proj2.bean;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.springframework.context.annotation.Primary;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ContractOrder")
public class ContractOrder extends BaseBean{
    private long quantity;
    private String state;

    @Temporal(TemporalType.DATE)
    @Column(name = "LodgementDate", nullable = true, length = 12)
    private Date LodgementDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "estimatedDeliveryDate", nullable = true, length = 12)
    private Date estimatedDeliveryDate;

    @ManyToOne
    @JoinColumn(name="SalesmanId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    @NotFound(action= NotFoundAction.IGNORE)
    private Staff salesman;

    @ManyToOne
    @NotFound(action=NotFoundAction.IGNORE)
    @JoinColumn(name="modelId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Model model;

    @ManyToOne
    @NotFound(action=NotFoundAction.IGNORE)
    @JoinColumn(name="contractId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private Contract contract;

    public void setState(String state) {
        this.state = state;
    }

    public String getState() {
        return state;
    }

    public long getQuantity() {
        return quantity;
    }

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }

    public Date getLodgementDate() {
        return LodgementDate;
    }

    public void setLodgementDate(Date lodgementDate) {
        LodgementDate = lodgementDate;
    }

    public Date getEstimatedDeliveryDate() {
        return estimatedDeliveryDate;
    }

    public void setEstimatedDeliveryDate(Date estimatedDeliveryDate) {
        this.estimatedDeliveryDate = estimatedDeliveryDate;
    }

    public Staff getSalesman() {
        return salesman;
    }

    public void setSalesman(Staff salesman) {
        this.salesman = salesman;
    }

    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }


}
