package com.example.proj2.bean;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.springframework.context.annotation.Primary;

import javax.persistence.*;

@Entity
@Table(name = "staff")
public class Staff extends BaseBean{

    private String name;
    private int age;
    private String gender;
    @Column(unique = true)
    private long number;
    @ManyToOne
    @NotFound(action= NotFoundAction.IGNORE)
    @JoinColumn(name="SupplyCenterId",foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private SupplyCenter SupplyCenter;
    private long mobile_number;
    private String type;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public long getNumber() {
        return number;
    }

    public void setNumber(long number) {
        this.number = number;
    }

    public com.example.proj2.bean.SupplyCenter getSupplyCenter() {
        return SupplyCenter;
    }

    public void setSupplyCenter(com.example.proj2.bean.SupplyCenter supplyCenter) {
        SupplyCenter = supplyCenter;
    }

    public long getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(long mobile_number) {
        this.mobile_number = mobile_number;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
