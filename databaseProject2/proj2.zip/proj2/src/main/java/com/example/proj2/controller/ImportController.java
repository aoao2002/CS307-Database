package com.example.proj2.controller;

import java.util.concurrent.atomic.AtomicLong;

import com.example.proj2.dao.SupplyCenterDao;
import com.example.proj2.service.*;
import com.example.proj2.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class ImportController {

    @Autowired
    private ImportService importService;
    @Autowired
    private APIService APIService;
    @Autowired
    private ContractOrderService contractOrderService;


    @RequestMapping("/importIniData")
    @ResponseBody
    public String importIniData(){
        importService.deleteAllTable();
        importService.importCenter();
        importService.importStaff();
        importService.importModel();
        importService.importEnterPrise();
        return "import success";
    }

    @RequestMapping("/stockIn")
    @ResponseBody
    public String stockIn(){
        APIService.stockIn();
        return  "Stock In has been done!!!!!!!!!!!!!!!!!!!!!!!!";
    }

    @RequestMapping("/placeOrder")
    @ResponseBody
    public String placeOrder(){
        APIService.placeOrder();
        return  "placeOrder has been done!!!!!!!!!!!!!!!!!!!!!!!!";
    }

    @RequestMapping("/One-step input")
    @ResponseBody
    public String OneStepInput(){
        importService.deleteAllTable();
        importService.importCenter();
        importService.importStaff();
        importService.importModel();
        importService.importEnterPrise();
        APIService.stockIn();
        APIService.placeOrder();
        contractOrderService.updateOrder();
        contractOrderService.deleteOrder();
        return  "OneStepInput has been done!!!!!!!!!!!!!!!!!!!!!!!!";
    }

    @RequestMapping("/truncateAllTable")
    @ResponseBody
    public String truncateAllTable(){
        importService.deleteAllTable();

        return  "truncateAllTable success";
    }


}
