package com.example.proj2.dao;

import com.example.proj2.bean.SupplyCenter;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.proj2.bean.Staff;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface SupplyCenterDao extends CommonDao<SupplyCenter>{

    SupplyCenter findByName(String Name);

    SupplyCenter save(SupplyCenter supplyCenter);
    //List<SupplyCenter> saveAll(List<SupplyCenter> centers);

    @Transactional
    @Modifying
    @Query(value = "truncate table supply_center RESTART IDENTITY CASCADE;",nativeQuery = true)
    void truncateTable();
}
