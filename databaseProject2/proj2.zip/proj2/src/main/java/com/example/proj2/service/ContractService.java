package com.example.proj2.service;

import java.util.List;
import com.example.proj2.bean.Contract;
import org.springframework.transaction.annotation.Transactional;
@Transactional
public interface ContractService {

    Contract findByNum(String num);

    int countContract();

}
