//用于保存相关实体
//即数据库的每一个表
//都应该基础于BaseBean


//用注释@Entity，表示它是一个 JPA Entity
//Hibernate automatically translates the entity into a table.
//我试过了！！！真的可以！！！

//@JoinColumn指定该实体类对应的表中引用的表的外键，name属性指定外键名称，referencedColumnName指定应用表中的字段名称
//@JoinColumn(name=”role_id”): 标注在连接的属性上(一般多对1的1)，指定了本类用1的外键名叫什么。
//@JoinTable(name="permission_role") ：标注在连接的属性上(一般多对多)，指定了多对多的中间表叫什么。

//主键@Id

package com.example.proj2.bean;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class BaseBean {

    //自增id的简单实现
    //annotated with @Id so that JPA recognizes it as the object’s ID.
    //annotated with @GeneratedValue to indicate that the ID should be generated automatically.
    //没有注释的值映射到对应表的col

    //没有参数的构造函数是给spring用的
    //我们可以手写带参数的构造函数，来生成对应表中某一行的对象
    //凭借该对象我们可以修改db
    //例子：
    //userRepository.save(new User("John Doe", "john.doe@example.com"));

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
