package com.example.proj2.service;

import java.util.List;
import com.example.proj2.bean.ContractOrder;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface ContractOrderService {

    List<ContractOrder> updateOrder();

    void deleteOrder();

    int countOrder();
    List<ContractOrder> findOrderByNum(String num);
    List<String> getFavoriteProductModel();
}