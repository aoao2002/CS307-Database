package com.example.proj2.bean;
import javax.persistence.*;


@Entity
@Table(name = "Location")
//@IdClass(LocationPk.class)
/**
 * 插入前需要保证不重复
 */
public class Location extends BaseBean {
    private String city;
    private String country;

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}
