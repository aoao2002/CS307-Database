package com.example.proj2.bean;

import javax.persistence.*;


@Entity
@Table(name = "Product")
public class Product extends BaseBean{
    @Column(unique = true)
    private String productCode;
    private String name;
    public Product(){

    }

    public Product(String productCode, String name) {
        this.productCode = productCode;
        this.name = name;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
