package com.example.proj2.dao;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.proj2.bean.Staff;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

//@repository是用来注解接口
//这个注解是将接口的一个实现类交给spring管理，完成注入依赖
//该接口不需要手写实现，SPA可以帮你实现他
//特殊的函数命名（findByName）, 可以自动生成根据主键查找对应数据的方法
//findAll() --> select *
//jpa
@Repository
public interface StaffDao extends CommonDao<Staff> {

    //@Modifying
    //hql
    //@Query(value = "from Staff where name= ?1")
    //@Query(nativeQuery = true, value = ":name")
    //List<Staff> findAllStaff(@Param("name") String name);


    Staff findByNumber(long number);

    @Query(nativeQuery = true,
        value = "select type, count(*) cnt from staff\n" +
                "group by type\n"
    )
    ArrayList<String> findNumberGroupByType();

//    @Query(nativeQuery = true,
//            value = "select * from staff"
//    )
//    ArrayList<String> findAll();

    List<Staff> findByType(String type);

    @Transactional
    @Modifying
    @Query(value = "truncate table staff RESTART IDENTITY CASCADE;",nativeQuery = true)
    void truncateTable();

    //List<Staff> saveAll(List<Staff> staffs);

}
