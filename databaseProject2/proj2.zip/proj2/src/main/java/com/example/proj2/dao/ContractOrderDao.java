package com.example.proj2.dao;

import com.example.proj2.bean.ContractOrder;
import com.example.proj2.bean.Model;
import com.example.proj2.bean.Staff;
import com.example.proj2.bean.Contract;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface ContractOrderDao extends CommonDao<ContractOrder>{

    List<ContractOrder> findByContract(Contract contract);

    List<ContractOrder> findByContractId(Long id);

    List<ContractOrder> findByContractIdAndModelIdAndSalesmanId(
            String contractNum,
            String modelName,
            String salesmanNumber

    );

    void deleteById(long id);

    ContractOrder save(ContractOrder contractOrder);

    List<ContractOrder> findAll();

    ContractOrder findByContractAndModelAndSalesman(Contract contract, Model model,Staff Salesman);

    @Query(nativeQuery = true,value="select *\n" +
            "from contract_order\n" +
            "join model m on m.id = contract_order.model_id\n" +
            "join staff s on s.id = contract_order.salesman_id\n" +
            "join contract c on c.id = contract_order.contract_id\n" +
            "where c.num=:contract and s.number=:salesman\n" +
            "order by estimated_delivery_date,m.model_name")
    List<ContractOrder> findByContractAndSalesman(
            @Param("contract") String contract,
            @Param("salesman") long salesman);

    @Query(nativeQuery = true,value="select * from\n" +
            "(select m.model_name,sum(contract_order.quantity) sum\n" +
            "from contract_order\n" +
            "join model m on m.id = contract_order.model_id\n" +
            "group by m.model_name) sub2\n" +
            "where sub2.sum=(\n" +
            "select max(sub1.sum)\n" +
            "from (\n" +
            "select m.model_name,sum(contract_order.quantity) from contract_order\n" +
            "join model m on m.id = contract_order.model_id\n" +
            "group by m.model_name\n" +
            ") sub1);")
    List<String> getFavoriteProductModel();

    void delete(ContractOrder contractOrder);

    @Transactional
    @Modifying
    @Query(value = "truncate table contract_order RESTART IDENTITY CASCADE;",nativeQuery = true)
    void truncateTable();
}
