//Dao(Data Access Object)层用于和数据库交互--> new 对应的dao，利用对象访问数据库
//继承JpaRepository
//在一个项目中，我们往往会创建一个公共接口来处理到数据库的请求，然后每个接口去继承它即可。
//我们就一个就好了吧。

package com.example.proj2.dao;
import com.example.proj2.bean.Staff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.proj2.bean.BaseBean;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

//两个参数，分别表示 —— 实体类型、主键类型
@Repository
public interface CommonDao<T extends BaseBean> extends JpaRepository<T, Long> {

    //在SQL的查询方法上面使用@Query注解，如涉及到删除和修改在需要加上@Modifying.
    //和数据库的交互写sql就好了，太爽了吧
    //返回值写 List<Staff> 就可以直接在service里面调用了

//    @Modifying
//    @Query("update Staff s set s.name=?1 where s.id=?2")
//    Integer modifyByNameAndId(String Name,Integer id);

    @Transactional
    @Modifying
    @Query(value = "SET FOREIGN_KEY_CHECKS = 0", nativeQuery = true)
    void cancelForeignKeyConstraint();
    @Transactional
    @Modifying
    @Query(value = "SET FOREIGN_KEY_CHECKS = 1", nativeQuery = true)
    void enableForeignKeyConstraint();

}

