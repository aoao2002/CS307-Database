//package com.example.proj2;
//import com.zaxxer.hikari.HikariConfig;
//import com.zaxxer.hikari.HikariDataSource;
//import org.junit.jupiter.api.Test;
//
//import java.sql.SQLException;
//
//public class TestHikari {
//
//    @Test
//    public void test01() throws SQLException {
//        HikariConfig config = new HikariConfig();
//        //配置连接数据库信息
//        source.setJdbcUrl("jdbc:postgresql://106.55.104.82:5432/cs307");
//        source.setUsername("checker");
//        source.setPassword("123456");
//
//        HikariDataSource source = new HikariDataSource(config);
//        System.out.println(source.getConnection());
//    }
//
//    @Test
//    public void test02() throws SQLException {
//        //直接初始化HikariDataSource
//        HikariDataSource source = new HikariDataSource();
//        source.setJdbcUrl("jdbc:postgresql://106.55.104.82:5432/cs307");
//        source.setUsername("checker");
//        source.setPassword("123456");
//        System.out.println(source.getConnection());
//    }
//}
