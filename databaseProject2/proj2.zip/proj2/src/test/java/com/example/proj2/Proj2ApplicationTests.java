//package com.example.proj2;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.transaction.annotation.EnableTransactionManagement;
//
//@SpringBootTest
//@EnableTransactionManagement
//class roj2ApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
